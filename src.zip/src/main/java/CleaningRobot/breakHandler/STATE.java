package CleaningRobot.breakHandler;

public enum STATE {
    WORKING,
    NEEDING,
    MECHANIC
}
